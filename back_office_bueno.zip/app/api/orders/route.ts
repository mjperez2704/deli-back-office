import { db } from '@/lib/db/connection';
import { orders, orderItems, products } from '@/lib/db/schema';
import { handleApiError, ApiResponse } from '@/lib/api-response';
import { z } from 'zod';
import { and, eq, inArray } from 'drizzle-orm';

// Esquema para validar la creación de un nuevo pedido
const createOrderSchema = z.object({
    customerId: z.number().int('ID de cliente inválido.'),
    storeId: z.number().int('ID de tienda inválido.'),
    deliveryAddressId: z.number().int('ID de dirección de entrega inválido.'),
    paymentMethod: z.enum(['cash', 'credit_card', 'paypal']),
    notes: z.string().optional(),
    // Los items del pedido: un array de objetos con productId y quantity
    items: z.array(z.object({
        productId: z.number().int(),
        quantity: z.number().int().positive(),
    })).min(1, 'El pedido debe tener al menos un artículo.'),
});

/**
 * Maneja las solicitudes GET para obtener todos los pedidos.
 * Se pueden añadir filtros por query params, ej: /api/orders?status=pending
 */
export async function GET(request: Request) {
    try {
        const { searchParams } = new URL(request.url);
        const status = searchParams.get('status');

        // Consulta con relaciones para obtener datos del cliente y la tienda
        const allOrders = await db.query.orders.findMany({
            where: status ? eq(orders.status, status as any) : undefined,
            with: {
                customer: { columns: { name: true, email: true } },
                store: { columns: { name: true } },
                items: { with: { product: true } }, // Incluir los productos de cada item
            },
            orderBy: (orders, { desc }) => [desc(orders.createdAt)],
        });

        return ApiResponse.success(allOrders);
    } catch (error) {
        return handleApiError(error, 'Error al obtener los pedidos.');
    }
}

/**
 * Maneja las solicitudes POST para crear un nuevo pedido.
 * Utiliza una transacción para garantizar la integridad de los datos.
 */
export async function POST(request: Request) {
    try {
        const body = await request.json();
        const validation = createOrderSchema.safeParse(body);

        if (!validation.success) {
            return ApiResponse.badRequest(validation.error.formErrors.fieldErrors);
        }

        const { customerId, storeId, deliveryAddressId, paymentMethod, notes, items } = validation.data;

        const productIds = items.map(item => item.productId);

        // En una transacción, ejecutamos todas las operaciones. Si algo falla, se revierte todo.
        const newOrder = await db.transaction(async (tx) => {
            // 1. Verificar que todos los productos existen y pertenecen a la tienda correcta
            const existingProducts = await tx.select()
                .from(products)
                .where(and(
                    eq(products.storeId, storeId),
                    inArray(products.id, productIds)
                ));

            if (existingProducts.length !== productIds.length) {
                throw new Error('Algunos productos no existen o no pertenecen a la tienda seleccionada.');
            }

            // 2. Calcular el monto total del pedido
            let totalAmount = 0;
            const productPriceMap = new Map(existingProducts.map(p => [p.id, p.price]));

            for (const item of items) {
                const price = productPriceMap.get(item.productId);
                if (price) {
                    totalAmount += parseFloat(price) * item.quantity;
                }
            }

            // 3. Crear el registro principal del pedido
            const [createdOrder] = await tx
                .insert(orders)
                .values({
                    customerId,
                    storeId,
                    deliveryAddressId,
                    paymentMethod,
                    totalAmount: totalAmount.toFixed(2), // Guardar con 2 decimales
                    notes,
                    status: 'pending', // Estado inicial
                })
                .returning();

            // 4. Crear los registros de los artículos del pedido (order_items)
            const orderItemsToInsert = items.map(item => ({
                orderId: createdOrder.id,
                productId: item.productId,
                quantity: item.quantity,
                price: productPriceMap.get(item.productId)!, // Precio al momento de la compra
            }));

            await tx.insert(orderItems).values(orderItemsToInsert);

            return createdOrder;
        });

        return ApiResponse.created(newOrder);

    } catch (error) {
        // Si el error es el que lanzamos manualmente, es un badRequest.
        if (error.message.includes('Algunos productos no existen')) {
            return ApiResponse.badRequest({ items: error.message });
        }
        return handleApiError(error, 'Error al crear el pedido.');
    }
}
