import { db } from '@/lib/db/connection';
import { products } from '@/lib/db/schema';
import { handleApiError, ApiResponse } from '@/lib/api-response';
import { z } from 'zod';
import { desc } from 'drizzle-orm';

// Esquema de validación para un nuevo producto
const createProductSchema = z.object({
    name: z.string().min(3, 'El nombre del producto es requerido.'),
    description: z.string().optional(),
    price: z.number().positive('El precio debe ser un número positivo.'),
    storeId: z.number().int('Se requiere el ID de la tienda.'),
    imageUrl: z.string().url('URL de imagen no válida.').optional(),
});

/**
 * Maneja las solicitudes GET para obtener todos los productos.
 * Permite filtrar por storeId a través de query params (ej: /api/products?storeId=1)
 */
export async function GET(request: Request) {
    try {
        const { searchParams } = new URL(request.url);
        const storeId = searchParams.get('storeId');

        let query = db.select().from(products).orderBy(desc(products.createdAt));

        if (storeId) {
            // Si se proporciona un storeId, filtramos los productos
            query = db.select().from(products).where(eq(products.storeId, Number(storeId))).orderBy(desc(products.createdAt));
        }

        const allProducts = await query;
        return ApiResponse.success(allProducts);
    } catch (error) {
        return handleApiError(error, 'Error al obtener los productos.');
    }
}

/**
 * Maneja las solicitudes POST para crear un nuevo producto.
 */
export async function POST(request: Request) {
    try {
        const body = await request.json();
        const validation = createProductSchema.safeParse(body);

        if (!validation.success) {
            return ApiResponse.badRequest(validation.error.formErrors.fieldErrors);
        }

        const newProduct = await db
            .insert(products)
            .values(validation.data)
            .returning();

        return ApiResponse.created(newProduct[0]);
    } catch (error) {
        // Maneja errores de llave foránea (ej: si storeId no existe)
        if (error.code === 'ER_NO_REFERENCED_ROW_2') {
            return ApiResponse.badRequest({ storeId: 'La tienda especificada no existe.' });
        }
        return handleApiError(error, 'Error al crear el producto.');
    }
}
