import { NextResponse } from 'next/server';
import { db } from '@/lib/db/connection';
import { deliveryZones } from '@/lib/db/schema';
import { handleApiError, ApiResponse } from '@/lib/api-response';
import { z } from 'zod';

// Esquema de validación para crear una zona.
// Asegura que el nombre tenga al menos 3 caracteres y que el área sea un polígono GeoJSON válido.
const createZoneSchema = z.object({
    name: z.string().min(3, 'El nombre debe tener al menos 3 caracteres.'),
    area: z.object({
        type: z.literal('Polygon'),
        coordinates: z.array(z.array(z.tuple([z.number(), z.number()]))),
    }),
});

/**
 * Maneja las solicitudes GET para obtener todas las zonas de entrega.
 */
export async function GET() {
    try {
        const allDeliveryZones = await db.select().from(deliveryZones);
        // Devuelve una respuesta exitosa con los datos de las zonas.
        return ApiResponse.success(allDeliveryZones);
    } catch (error) {
        // Maneja cualquier error que ocurra durante la consulta.
        return handleApiError(error, 'Error al obtener las zonas de entrega');
    }
}

/**
 * Maneja las solicitudes POST para crear una nueva zona de entrega.
 */
export async function POST(request: Request) {
    try {
        const body = await request.json();
        // Valida el cuerpo de la solicitud con el esquema definido.
        const validation = createZoneSchema.safeParse(body);

        if (!validation.success) {
            // Si la validación falla, devuelve un error 400 con los detalles.
            return ApiResponse.badRequest(validation.error.formErrors.fieldErrors);
        }

        const { name, area } = validation.data;

        // Inserta la nueva zona en la base de datos.
        // El objeto 'area' se convierte a un string JSON para almacenarlo.
        const newZone = await db
            .insert(deliveryZones)
            .values({ name, area: JSON.stringify(area) })
            .returning();

        // Devuelve una respuesta 201 (Created) con la zona recién creada.
        return ApiResponse.created(newZone[0]);
    } catch (error) {
        // Maneja cualquier error durante la creación.
        return handleApiError(error, 'Error al crear la zona de entrega');
    }
}
