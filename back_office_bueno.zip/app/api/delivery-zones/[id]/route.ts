import { NextResponse } from 'next/server';
import { db } from '@/lib/db/connection';
import { deliveryZones } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import { handleApiError, ApiResponse } from '@/lib/api-response';
import { z } from 'zod';

// Esquema de validación para actualizar una zona (permite campos opcionales).
const updateZoneSchema = z.object({
    name: z.string().min(3, 'El nombre debe tener al menos 3 caracteres').optional(),
    area: z.object({
        type: z.literal('Polygon'),
        coordinates: z.array(z.array(z.tuple([z.number(), z.number()]))),
    }).optional(),
});

// Función auxiliar para obtener una zona y verificar si existe.
async function getZoneById(id: number) {
    const zone = await db.select().from(deliveryZones).where(eq(deliveryZones.id, id));
    if (zone.length === 0) {
        // Lanza un error si no se encuentra la zona.
        throw new Error('Zona de entrega no encontrada');
    }
    return zone[0];
}

export async function GET(request: Request, { params }: { params: { id: string } }) {
    try {
        const id = Number(params.id);
        const zone = await getZoneById(id);
        return ApiResponse.success(zone);
    } catch (error) {
        if (error.message === 'Zona de entrega no encontrada') {
            return ApiResponse.notFound(error.message);
        }
        return handleApiError(error, 'Error al obtener la zona de entrega');
    }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
    try {
        const id = Number(params.id);
        // Primero, verifica que la zona exista.
        await getZoneById(id);

        const body = await request.json();
        const validation = updateZoneSchema.safeParse(body);

        if (!validation.success) {
            return ApiResponse.badRequest(validation.error.formErrors.fieldErrors);
        }

        const updatedZone = await db
            .update(deliveryZones)
            .set({
                ...validation.data,
                // Si el área se está actualizando, conviértela a string JSON.
                area: validation.data.area ? JSON.stringify(validation.data.area) : undefined,
            })
            .where(eq(deliveryZones.id, id))
            .returning();

        return ApiResponse.success(updatedZone[0]);
    } catch (error) {
        if (error.message === 'Zona de entrega no encontrada') {
            return ApiResponse.notFound(error.message);
        }
        return handleApiError(error, 'Error al actualizar la zona de entrega');
    }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
    try {
        const id = Number(params.id);
        // Verifica que la zona exista antes de eliminarla.
        await getZoneById(id);

        await db.delete(deliveryZones).where(eq(deliveryZones.id, id));
        // Devuelve una respuesta 204 (No Content) que indica éxito.
        return ApiResponse.noContent();
    } catch (error) {
        if (error.message === 'Zona de entrega no encontrada') {
            return ApiResponse.notFound(error.message);
        }
        return handleApiError(error, 'Error al eliminar la zona de entrega');
    }
}
