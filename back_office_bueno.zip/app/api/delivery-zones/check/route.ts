import { NextResponse } from 'next/server';
import { db } from '@/lib/db/connection';
import { deliveryZones } from '@/lib/db/schema';
import { ApiResponse, handleApiError } from '@/lib/api-response';
import { z } from 'zod';
// Usaremos una librería para verificar si un punto está en un polígono.
import isPointInPolygon from 'point-in-polygon';

const checkZoneSchema = z.object({
    lat: z.number(),
    lng: z.number(),
});

export async function POST(request: Request) {
    try {
        const body = await request.json();
        const validation = checkZoneSchema.safeParse(body);

        if (!validation.success) {
            return ApiResponse.badRequest(validation.error.formErrors.fieldErrors);
        }

        const { lat, lng } = validation.data;
        // Obtenemos todas las zonas de la base de datos.
        const allZones = await db.select().from(deliveryZones);

        let isAvailable = false;
        let zoneName = '';
        let zoneId = null;

        // Iteramos sobre cada zona para ver si el punto está dentro.
        for (const zone of allZones) {
            // El área se almacena como un string JSON, así que lo parseamos.
            const area = JSON.parse(zone.area as string);
            // Extraemos las coordenadas del polígono.
            const polygonCoordinates = area.coordinates[0].map((coord: [number, number]) => [coord[0], coord[1]]);

            const point = [lng, lat];

            if (isPointInPolygon(point, polygonCoordinates)) {
                isAvailable = true;
                zoneName = zone.name;
                zoneId = zone.id;
                break; // Si encontramos una zona, no necesitamos seguir buscando.
            }
        }

        return ApiResponse.success({ isAvailable, zoneName, zoneId });
    } catch (error) {
        return handleApiError(error, 'Error al verificar la zona de entrega');
    }
}import { type NextRequest, NextResponse } from "next/server"
import { checkDeliveryZoneCoverage, mockDeliveryZones } from "@/lib/services/delivery-zones"

// POST - Verificar si una ubicación está en zona de cobertura
export async function POST(request: NextRequest) {
  try {
    const { lat, lng } = await request.json()

    if (!lat || !lng) {
      return NextResponse.json({ success: false, error: "Latitud y longitud son requeridas" }, { status: 400 })
    }

    // TODO: Obtener zonas de la base de datos
    // const zones = await db.query('SELECT * FROM delivery_zones WHERE is_active = true')

    const result = checkDeliveryZoneCoverage({ lat, lng }, mockDeliveryZones)

    return NextResponse.json({
      success: true,
      data: result,
    })
  } catch (error) {
    console.error("Error checking delivery zone:", error)
    return NextResponse.json({ success: false, error: "Error al verificar zona de entrega" }, { status: 500 })
  }
}
